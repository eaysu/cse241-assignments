public interface visual
{
    // visual interface for video and image
    public double get_dimension();
    public void info();
}