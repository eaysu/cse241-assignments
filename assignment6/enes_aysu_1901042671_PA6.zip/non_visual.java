public interface non_visual
{
    // non_visual interface for audio and text
    public void info();
}