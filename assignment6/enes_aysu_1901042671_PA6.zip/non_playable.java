public interface non_playable
{
    // non_playable interface for image and text
    public void info();
}