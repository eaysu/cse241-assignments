public interface playable
{
    // playable interface for audio and video 
    public double get_duration();
    public void info();
}
